package com.test.collection.arrylist;

import java.util.ArrayList;
import java.util.LinkedList;

public class ArrayListLinkedListCompare {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 
		
		ArrayList<String> alist = new ArrayList<String>();
		LinkedList<String> linkedlist = new LinkedList<String>();
		final int loopCnt = 50000;
		long startTime = System.currentTimeMillis();
		for(int i=0;i<loopCnt;i++){
			alist.add(String.valueOf(i));
		}
		long endTime = System.currentTimeMillis();
		System.out.println("arrayList insert time >> "+(endTime - startTime));
		
		startTime = System.currentTimeMillis();
		for(int i=0;i<loopCnt;i++){
			alist.get(i);
		}
		endTime = System.currentTimeMillis();
		System.out.println("arrayList access element  time >> "+(endTime - startTime) + "  size="+ alist.size());
		
		startTime = System.currentTimeMillis();
		for(int i=0;i<alist.size();i++){
			alist.remove(i);
		}
		endTime = System.currentTimeMillis();
		System.out.println("arrayList remove time >> "+(endTime - startTime));
		
		startTime = System.currentTimeMillis();
		for(int i=0;i<loopCnt;i++){
			linkedlist.addLast(String.valueOf(i));
		}
		endTime = System.currentTimeMillis();
		System.out.println("LinkedList insert time >> "+(endTime - startTime)+ "  size="+ linkedlist.size());
		
		startTime = System.currentTimeMillis();
		for(int i=0;i<loopCnt;i++){
			linkedlist.get(i);
		}
		endTime = System.currentTimeMillis();
		System.out.println("LinkedList access element time by random access "+(endTime - startTime));
		
		startTime = System.currentTimeMillis();
		for(int i=0;i<loopCnt;i++){
			//linkedlist.remove(String.valueOf(i));
			//linkedlist.removeLast();
			linkedlist.removeFirst();
		}
		
		endTime = System.currentTimeMillis();
		System.out.println("LinkedList remove time >> "+(endTime - startTime)  + "  size"+ linkedlist.size());
		
	}

}
