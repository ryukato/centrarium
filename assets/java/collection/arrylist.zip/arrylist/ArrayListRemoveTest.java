package com.test.collection.arrylist;

import java.util.ArrayList;
import java.util.List;

public class ArrayListRemoveTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<Integer> alist = new ArrayList<Integer>();
		//we adding primitive type int values to ArrayList instance, so the values is auto-boxed and inserted to the ArrayList instance
		alist.add(1);
		alist.add(2);
		alist.add(3);
		alist.add(4);

		//I guess you can figure out difference belwo two remove methods
		alist.remove(1);  // which element do you expect to be removed?   >> remove element positioned at 1
		alist.remove(new Integer(3)); // which element do you expect to be removed?  >> remove elements that Integer instance whose value 3, positioned 2.
		
		System.out.println(alist);
	}

}
