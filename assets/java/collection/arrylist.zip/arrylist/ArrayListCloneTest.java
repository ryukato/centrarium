package com.test.collection.arrylist;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ArrayListCloneTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ArrayListTestDummy a1 = new ArrayListTestDummy("1");
		List<ArrayListTestDummy> alist = new ArrayList<ArrayListTestDummy>();
		for (int i = 0; i < 1; i++) {
			alist.add(new ArrayListTestDummy(String.valueOf(i)));
		}
		//test clone of arraylist >> shallow copy
		List<ArrayListTestDummy> clonedAlist = (List<ArrayListTestDummy>) ((ArrayList)alist).clone();
		printCompareResult(alist, clonedAlist,"Shallow copy clone");
		
		
		
		//test copy list into another list   >> shallow copu
		List<ArrayListTestDummy> clist = new ArrayList<ArrayListTestDummy>(alist);
		//printCompareResult(alist, clist);

		
		List<ArrayListTestDummy> clist2 = new ArrayList<ArrayListTestDummy>(alist.size());
		clist2.add(null);
		Collections.copy(clist2, alist);		
		//printCompareResult(alist, clist2);
		
		
		alist.get(0).setName("222");
		List<ArrayListTestDummy> clonedList = deepCopyList(alist);
		printCompareResult(alist, clonedList,"Deep copy clone");
		
		System.out.println("-------------------------------------------System.arrcopy Test-----------------------------------------------");
		ArrayListTestDummy[] arrDummy = new ArrayListTestDummy[alist.size()];
		System.arraycopy(alist.toArray(),0,arrDummy,0,alist.size());
		List<ArrayListTestDummy> arrCopiedList = Arrays.asList(arrDummy);
		alist.get(0).setName("new Name");
		System.out.println(arrCopiedList);
		
		
		
	}
	private static void printCompareResult(List<ArrayListTestDummy> list1, List<ArrayListTestDummy> list2,String testName){
		System.out.println("-------------------------------------------"+testName+"-----------------------------------------------");
		for(int i=0;i<list1.size();i++){
			ArrayListTestDummy originalDm = list1.get(i);
			//change name attribute of original ArrayListTestDummy instance
			originalDm.setName("222");
			ArrayListTestDummy copyDm = list2.get(i);
			printCompareTwoInstance(originalDm,copyDm);
		}
	}
	
	private static void printCompareTwoInstance(ArrayListTestDummy a1, ArrayListTestDummy a2){
		System.out.println("both are same instance >> "+ (a1==a2));
		System.out.println("hashcode of  a1>> "+ (a1.hashCode()));
		System.out.println("hashcode of  a2>> "+ (a2.hashCode()));
		System.out.println("both are equal  >> "+ (a1.equals(a2)));
		System.out.println("name of a1  >> "+ (a1.toString()) + " / " + "name of a2  >> "+ (a2.toString()));
	}
	
	private static  List<ArrayListTestDummy> deepCopyList(List<ArrayListTestDummy> l1){
		Iterator<ArrayListTestDummy> it = l1.iterator();
		List<ArrayListTestDummy> clonedList = new ArrayList<ArrayListTestDummy>(l1.size());
		while(it.hasNext()){
			try {
				ArrayListTestDummy originalEm = it.next();
				ArrayListTestDummy clonedEm = (ArrayListTestDummy)originalEm.clone();
				clonedList.add(clonedEm);
			} catch (CloneNotSupportedException e) {
				e.printStackTrace();
			}
		}
		return clonedList;
	}
}
