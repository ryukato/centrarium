package com.test.collection.arrylist;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArraysAsListTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String[] arrStr = new String[]{"a","b","c"};
		//fixed size list, can NOT add or remove since internal array object of the returned list obect is final
		//so can NOT change its size
		//asList returns ArrayList but the ArrayList object is not the one that in java.util package.
		//the returned list is inner class Object of Arrays
		List<String> list = Arrays.asList(arrStr);
		
		System.out.println("type="+ list.getClass().getName());
		System.out.println(printArray(arrStr));
		System.out.println(list.toString());
		
		//to make change to list, then needs to change source array
		//which means list take reference of objects belongs to the array
		arrStr[0] = "new";
		
		//list.add("aaa");
		System.out.println(printArray(arrStr));
		System.out.println(list.toString());

	}
	
	public static String printArray(String[] arr){
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for(int i=0;i<arr.length;i++){
			if(i!=0){
				sb.append(", ");
			}
			sb.append(""+arr[i]);
		}
		sb.append("]");
		
		return sb.toString();
	}
	

}
