package com.test.collection.arrylist;

import java.util.ArrayList;
import java.util.List;

public class ConvertArrayListToArray {
	public static void main(String[] args){
		List<String> alist = new ArrayList<String>();
		alist.add("1");
		alist.add("2");
		alist.add("3");
		alist.add("4");
	
		//have to cast to the type of elements event though we declared type of elements by generic
		String[] arrStr =new String[alist.size()];
		alist.toArray(arrStr);
		System.out.println( printArray(arrStr));
		//what happend to copied array  if replace the second elements of ArrayList instance whose original array instance
		//>> nothing, since the copying was deep copy, I think.
		alist.set(1,"new");
		System.out.println( printArray(arrStr));
	}
	public static String printArray(Object[] arr){
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for(int i=0;i<arr.length;i++){
			if(i!=0){
				sb.append(", ");
			}
			sb.append(""+arr[i]);
		}
		sb.append("]");
		
		return sb.toString();
	}
}
