package com.test.collection.arrylist;

public class ArrayListTestDummy implements Cloneable {
	private String name;
	
	public ArrayListTestDummy(String n){
		this.name = n;
	}

	public final String getName() {
		return name;
	}

	public final void setName(String name) {
		this.name = name;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	@Override
	public String toString() {
		return "ArrayListTestDummy [name=" + name + "]";
	}
	
	
}
