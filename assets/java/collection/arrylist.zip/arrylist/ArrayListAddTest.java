package com.test.collection.arrylist;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ArrayListAddTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/*
		 when add elemens which is primitive type  to ArrayList with add methods, then  the primitive type variable auto-boxed(wrapped) to Wrapper class
		 int >> Integer
		 long >> Long
		 double >> Double
		 float >> Float
		 so on...
		 For more information about wrapper class, refer to http://en.wikipedia.org/wiki/Primitive_wrapper_class
		 
		 */
		
		//create ArrayList instance with default constructor
		List<String> alist = new ArrayList<String>();
		//just normal insertion to ArrayList
		alist.add("1");   // the element is going  to be positioned at 0, since the inserted elements saved into the internal Array object.
		System.out.println(alist); //call toString method
		//add insertion with position, if there is elements at the specified position, then the existing elemens move to after inserted element
		//and if the size fo current ArrayList instance is less then given position value, then IndexOutOfBoundsException is going to be thrown.
		alist.add("dummy");
		alist.add(1,"2");
		alist.remove(2); //remove "dummy" from the ArrayList instance
		System.out.println(alist); //call toString method
		
		Collection<String> c = new ArrayList<String>();
		c.add("3");
		c.add("4");
		c.add("5");
		
		//copy elements from Collection instance and insert ArrayList instance with start position where insertion start at
		alist.addAll(alist.size(),c);
		System.out.println(alist); //call toString method
		
		Collection<String> c1 = new ArrayList<String>();
		c1.add("6");
		c1.add("7");
		c1.add("8");
		//copy elements from Collection instance and insert ArrayList instance, position of the inserted elements starts from size of the ArrayList instance +1
		//,which means adding new elements into last
		alist.addAll(c1);
		System.out.println(alist); //call toString method
	}

}
